package caracteristica;

public class Bujia {

    private String material; // Ej: iridio, platino, cobre
    private int vidaUtilKm; // en kilómetros

    public Bujia(String material, int vidaUtilKm) {
        this.material = material;
        this.vidaUtilKm = vidaUtilKm;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getVidaUtilKm() {
        return vidaUtilKm;
    }

    public void setVidaUtilKm(int vidaUtilKm) {
        this.vidaUtilKm = vidaUtilKm;
    }

    @Override
    public String toString() {
        return "Bujias{" +
                "material='" + material + '\'' +
                ", vidaUtilKm=" + vidaUtilKm +
                '}';
    }
}