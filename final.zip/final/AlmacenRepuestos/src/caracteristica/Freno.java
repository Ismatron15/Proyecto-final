package caracteristica;

public class Freno {

    private String tipoFreno; // Ej: disco, tambor
    private boolean tieneSensorDesgaste;

    public Freno(String tipoFreno, boolean tieneSensorDesgaste) {
        this.tipoFreno = tipoFreno;
        this.tieneSensorDesgaste = tieneSensorDesgaste;
    }

    public String getTipoFreno() {
        return tipoFreno;
    }

    public void setTipoFreno(String tipoFreno) {
        this.tipoFreno = tipoFreno;
    }

    public boolean isTieneSensorDesgaste() {
        return tieneSensorDesgaste;
    }

    public void setTieneSensorDesgaste(boolean tieneSensorDesgaste) {
        this.tieneSensorDesgaste = tieneSensorDesgaste;
    }

    @Override
    public String toString() {
        return "Freno{" +
                "tipoFreno='" + tipoFreno + '\'' +
                ", tieneSensorDesgaste=" + tieneSensorDesgaste +
                '}';
    }
}