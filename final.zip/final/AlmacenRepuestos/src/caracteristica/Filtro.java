package caracteristica;

    public class Filtro {
private String tipoFiltro; // Ej: aire, aceite, combustible
private boolean reutilizable;

public Filtro(String tipoFiltro, boolean reutilizable) {
    this.tipoFiltro = tipoFiltro;
    this.reutilizable = reutilizable;
}

public String getTipoFiltro() {
    return tipoFiltro;
}

public void setTipoFiltro(String tipoFiltro) {
    this.tipoFiltro = tipoFiltro;
}

public boolean isReutilizable() {
    return reutilizable;
}

public void setReutilizable(boolean reutilizable) {
    this.reutilizable = reutilizable;
}

@Override
public String toString() {
    return "Filtro{" +
            "tipoFiltro='" + tipoFiltro + '\'' +
            ", reutilizable=" + reutilizable +
            '}';
}
}