package caracteristica;
public class Aceite {

    private String tipoAceite; // Ej: sintético, semisintético
    private String viscosidad; // Ej: 10W-30

    public Aceite(String tipoAceite, String viscosidad) {
        this.tipoAceite = tipoAceite;
        this.viscosidad = viscosidad;
    }

    public String getTipoAceite() {
        return tipoAceite;
    }

    public void setTipoAceite(String tipoAceite) {
        this.tipoAceite = tipoAceite;
    }

    public String getViscosidad() {
        return viscosidad;
    }

    public void setViscosidad(String viscosidad) {
        this.viscosidad = viscosidad;
    }

    @Override
    public String toString() {
        return "Aceite{" +
                "tipoAceite='" + tipoAceite + '\'' +
                ", viscosidad='" + viscosidad + '\'' +
                '}';
    }
}