package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {

    private static final String HOST = "localhost";
    private static final int PORT = 3306;
    private static final String DB = "inventario"; // Cambiado aquí
    private static final String USER = "root";
    private static final String PASS = "sasasa";

    private static final String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB +
            "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}

