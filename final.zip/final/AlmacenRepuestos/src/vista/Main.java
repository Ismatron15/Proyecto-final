package vista;

import dao.RepuestoDAO;
import modelo.*;
import caracteristica.*;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RepuestoDAO repuestoDAO = new RepuestoDAO();

        while (true) {
            System.out.println("\n==============================");
            System.out.println("   INVENTARIO DE REPUESTOS");
            System.out.println("==============================");
            System.out.println("1) Agregar repuesto");
            System.out.println("2) Mostrar inventario");
            System.out.println("3) Calcular valor total");
            System.out.println("4) Eliminar repuesto por nombre");
            System.out.println("5) Salir");

            int op = readIntInRange(sc, "Elige una opción: ", 1, 5);

            switch (op) {
                case 1 -> {
                    try {
                        int categoriaId = readInt(sc, "ID de categoría: ");

                        System.out.println("\nTipo de repuesto:");
                        System.out.println("1) Filtro");
                        System.out.println("2) Aceite");
                        System.out.println("3) Freno");
                        System.out.println("4) Bujías");

                        int tipo = readIntInRange(sc, "Selecciona tipo (1-4): ", 1, 4);

                        String nombre = readString(sc, "Nombre del repuesto: ");
                        double precio = readDouble(sc, "Precio: ");
                        int stock = readInt(sc, "Stock: ");
                        String marca = readString(sc, "Marca del vehículo: ");
                        int garantia = readInt(sc, "Garantía (meses): ");

                        RepuestoAutomotriz rep;

                        switch (tipo) {
                            case 1 -> {
                                String tipoFiltro = readString(sc, "Tipo de filtro (aire, aceite, combustible): ");
                                boolean reutilizable = readBoolean(sc, "¿Es reutilizable? (s/n): ");
                                Filtro filtro = new Filtro(tipoFiltro, reutilizable);
                                rep = new RepuestoAutomotriz(nombre, precio, stock, marca, garantia) {
                                    @Override
                                    public String getTipo() {
                                        return "Filtro";
                                    }
                                };
                            }
                            case 2 -> {
                                String tipoAceite = readString(sc, "Tipo de aceite (sintético, semisintético): ");
                                String viscosidad = readString(sc, "Viscosidad (ej: 10W-30W): ");
                                Aceite aceite = new Aceite(tipoAceite, viscosidad);
                                rep = new RepuestoAutomotriz(nombre, precio, stock, marca, garantia) {
                                    @Override
                                    public String getTipo() {
                                        return "Aceite";
                                    }
                                };
                            }
                            case 3 -> {
                                String tipoFreno = readString(sc, "Tipo de freno (disco, tambor): ");
                                boolean sensor = readBoolean(sc, "¿Tiene sensor de desgaste? (s/n): ");
                                Freno freno = new Freno(tipoFreno, sensor);
                                rep = new RepuestoAutomotriz(nombre, precio, stock, marca, garantia) {
                                    @Override
                                    public String getTipo() {
                                        return "Freno";
                                    }
                                };
                            }
                            case 4 -> {
                                String material = readString(sc, "Material (iridio, platino, cobre): ");
                                int vidaUtilKm = readInt(sc, "Vida útil (km): ");
                                Bujia bujia = new Bujia(material, vidaUtilKm);
                                rep = new RepuestoAutomotriz(nombre, precio, stock, marca, garantia) {
                                    @Override
                                    public String getTipo() {
                                        return "Bujías";
                                    }
                                };
                            }
                            default -> throw new IllegalStateException("Tipo inválido");
                        }

                        repuestoDAO.insertarRepuestoAutomotriz(rep, categoriaId);
                        System.out.println("✔️ Repuesto agregado correctamente.");

                    } catch (SQLException e) {
                        System.out.println("❌ Error MySQL al agregar:");
                        System.out.println(e.getMessage());
                    } catch (Exception e) {
                        System.out.println("❌ Error general:");
                        System.out.println(e.getMessage());
                    }
                }

                case 2 -> {
                    try {
                        repuestoDAO.mostrarInventarioSinCategoria();
                    } catch (SQLException e) {
                        System.out.println("❌ Error MySQL al listar:");
                        System.out.println(e.getMessage());
                    }
                }

                case 3 -> {
                    try {
                        double total = repuestoDAO.calcularValorTotal();
                        System.out.printf("💰 Valor total del inventario: $%.2f%n", total);
                    } catch (SQLException e) {
                        System.out.println("❌ Error MySQL al calcular total:");
                        System.out.println(e.getMessage());
                    }
                }

                case 4 -> {
                    try {
                        String nombre = readString(sc, "Nombre exacto del repuesto a eliminar: ");
                        int borrados = repuestoDAO.eliminarPorNombre(nombre);

                        if (borrados > 0) {
                            System.out.println("🗑️ Eliminado(s): " + borrados);
                        } else {
                            System.out.println("⚠ No se encontró ningún repuesto con ese nombre.");
                        }
                    } catch (SQLException e) {
                        System.out.println("❌ Error MySQL al eliminar:");
                        System.out.println(e.getMessage());
                    }
                }

                case 5 -> {
                    System.out.println("👋 Saliendo...");
                    sc.close();
                    return;
                }
            }
        }
    }

    // ---------------- HELPERS ----------------

    private static int readInt(Scanner sc, String msg) {
        while (true) {
            System.out.print(msg);
            String s = sc.nextLine().trim();
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.println("⚠ Ingresa un número entero válido.");
            }
        }
    }

    private static int readIntInRange(Scanner sc, String msg, int min, int max) {
        while (true) {
            int val = readInt(sc, msg);
            if (val >= min && val <= max) return val;
            System.out.printf("⚠ Ingresa un número entre %d y %d.%n", min, max);
        }
    }

    private static double readDouble(Scanner sc, String msg) {
        while (true) {
            System.out.print(msg);
            String s = sc.nextLine().trim().replace(",", ".");
            try {
                return Double.parseDouble(s);
            } catch (NumberFormatException e) {
                System.out.println("⚠ Ingresa un número válido (ej: 10.50).");
            }
        }
    }

    private static String readString(Scanner sc, String msg) {
        while (true) {
            System.out.print(msg);
            String s = sc.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("⚠ No puede estar vacío.");
        }
    }

    private static boolean readBoolean(Scanner sc, String msg) {
        while (true) {
            System.out.print(msg);
            String input = sc.nextLine().trim().toLowerCase();
            if (input.equals("s")) return true;
            if (input.equals("n")) return false;
            System.out.println("⚠ Ingresa 's' para sí o 'n' para no.");
        }
    }
}

