package dao;

import db.ConexionDB;
import modelo.RepuestoAutomotriz;

import java.sql.*;


public class RepuestoDAO {

    public void insertarRepuestoAutomotriz(RepuestoAutomotriz r, int categoriaId) throws SQLException {
        String sql = "INSERT INTO RepuestoAutomotriz (Nombre, Precio, Stock, marcaVehiculo, garantiaMeses, categoria_id) " +
                "VALUES (?,?,?,?,?,?)";


        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, r.getNombre());
            ps.setDouble(2, r.getPrecio());
            ps.setInt(3, r.getStock());
            ps.setString(4, r.getMarcaVehiculo());
            ps.setInt(5, r.getGarantiaMeses());
            ps.setInt(6, categoriaId);

            ps.executeUpdate();
        }
    }

    public static void mostrarInventarioSinCategoria() throws SQLException {

        String sql = """
        SELECT nombre, precio, stock, marcaVehiculo, garantiaMeses, categoria_id
        FROM RepuestoAutomotriz
        ORDER BY nombre
    """;

        try (Connection cn = db.ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            boolean hay = false;
            while (rs.next()) {
                hay = true;
                System.out.printf(
                        " - %s | $%.2f | stock=%d | marca=%s | garantía=%d | categoria_id=%d%n",
                        rs.getString("nombre"),
                        rs.getDouble("precio"),
                        rs.getInt("stock"),
                        rs.getString("marcaVehiculo"),
                        rs.getInt("garantiaMeses"),
                        rs.getInt("categoria_id")
                );
            }

            if (!hay) {
                System.out.println("📭 No hay repuestos registrados.");
            }
        }
    }

    public int eliminarPorNombre(String nombre) throws SQLException {
        String sql = "DELETE FROM RepuestoAutomotriz WHERE Nombre = ?";
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, nombre);
            return ps.executeUpdate();
        }
    }


    public double calcularValorTotal() throws SQLException {
        String sql = "SELECT IFNULL(SUM(precio * stock),0) AS total FROM RepuestoAutomotriz";
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble("total");
            return 0;
        }
    }
}
