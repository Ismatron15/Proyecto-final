package modelo;

public class RepuestoAutomotriz extends Repuesto {

    private String marcaVehiculo;
    private int garantiaMeses;

    public RepuestoAutomotriz(String nombre, double precio, int stock,
                              String marcaVehiculo, int garantiaMeses) {
        super(nombre, precio, stock);
        this.marcaVehiculo = marcaVehiculo;
        this.garantiaMeses = garantiaMeses;
    }

    public String getMarcaVehiculo() {
        return marcaVehiculo;
    }

    public int getGarantiaMeses() {
        return garantiaMeses;
    }

    @Override
    public String getTipo() {
        return "Repuesto Automotriz";
    }

    @Override
    public String toString() {
        return super.toString() +
                " | Marca: " + marcaVehiculo +
                " | Garantía: " + garantiaMeses + " meses";
    }
}

